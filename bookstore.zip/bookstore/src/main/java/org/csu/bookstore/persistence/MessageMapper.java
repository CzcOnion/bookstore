package org.csu.bookstore.persistence;

import org.apache.ibatis.annotations.Mapper;
import org.csu.bookstore.domain.Message;
import org.csu.bookstore.domain.MessageReply;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Mapper
@Component(value ="MessageMapper")
public interface MessageMapper {

    List<Message> getMessageByReviewId(int reviewId);

    List<Message> getMessageByUserId(int userId);

    List<MessageReply> getMessageReplyByMessageId(int messageId);

    @Transactional
    void insertMessage(Message message);

    @Transactional
    void updateMessage(Message message);

    @Transactional
    void deleteMessage(int messageId);

    List<MessageReply> getMessageReplyByUserId(int userId);

    @Transactional
    void insertMessageReply(MessageReply messagereply);

    @Transactional
    void deleteMessageReply(int messagereplyId);

    int getNextMessageId();

    int getNextMessageReplyId();
}
