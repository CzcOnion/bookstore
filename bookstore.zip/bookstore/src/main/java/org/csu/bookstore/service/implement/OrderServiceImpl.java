package org.csu.bookstore.service.implement;

import org.csu.bookstore.domain.Book;
import org.csu.bookstore.domain.Order;
import org.csu.bookstore.domain.OrderDetail;
import org.csu.bookstore.persistence.BookMapper;
import org.csu.bookstore.persistence.OrderMapper;
import org.csu.bookstore.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderServiceImpl implements OrderService{

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private BookMapper bookMapper;

    @Override
    public List<Order> getOrderList(int userId){
        return orderMapper.getOrderByUserId(userId);
    }

    @Override
    public void insertOrder(Order order){
        //获取orderId
        order.setOrderId(orderMapper.getNextOrderId());
        for(int i = 0;i<order.getOrderDetailList().size();i++)
        {
            //存入订单明细
            OrderDetail orderDetail = order.getOrderDetailList().get(i);
            orderMapper.addOrderDetail(orderDetail);
            //书本数量更新
            Book book = bookMapper.getBookByBookId(orderDetail.getBookId());
            book.setQuantity(book.getQuantity()-orderDetail.getCount());
        }
        orderMapper.addOrder(order);
    }

    @Override
    public Order getOrder(int orderId){
        Order order = orderMapper.getOrderByOrderId(orderId);
        order.setOrderDetailList(orderMapper.getOrderDetailByOrderId(orderId));
        return order;
    }

    @Override
    public void updateOrder(Order order){
        orderMapper.updateOrderByOrderId(order);
    }

}
