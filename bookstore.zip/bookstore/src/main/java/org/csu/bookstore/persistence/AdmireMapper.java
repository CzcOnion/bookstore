package org.csu.bookstore.persistence;

import org.apache.ibatis.annotations.Mapper;
import org.csu.bookstore.domain.Admire;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Mapper
@Component(value ="AdmireMapper")
public interface AdmireMapper {

    List<Admire> getAdmireByReviewId(int reviewId);

    @Transactional
    void insertAdmire(Admire admire);

    @Transactional
    void deleteAdmire(Admire admire);

    int getNextAdmireId();
}
