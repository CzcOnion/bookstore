package org.csu.bookstore.controller;

import org.csu.bookstore.domain.User;
import org.csu.bookstore.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;

@Controller
public class UserController {

    @Autowired
    private UserService userService;


    @PostMapping("/login")
    public String login(@RequestParam("userId")String userId,@RequestParam("password") String password,Model model, HttpSession session){
        System.out.print(Integer.getInteger(userId));
        System.out.print(password);
        if(userId!=null && password!=null){
            System.out.print(userService);
            System.out.print(userService.getUser(Integer.getInteger(userId),password));
            User user = userService.getUser(Integer.getInteger(userId),password);
//            if(user != null)
////            {
////                return "index";
////            }
////            else{
////                return "product-detail";
////            }
        }
        return "index";
    }
}
