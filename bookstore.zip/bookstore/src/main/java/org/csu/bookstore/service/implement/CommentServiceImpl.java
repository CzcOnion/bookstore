package org.csu.bookstore.service.implement;

import org.csu.bookstore.domain.Comment;
import org.csu.bookstore.persistence.CommentMapper;
import org.csu.bookstore.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;

public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentMapper commentMapper;

    @Override
    public void insertComment(Comment comment) {
        comment.setCommentId(commentMapper.getNextCommentId());
        commentMapper.insertComment(comment);
    }

    @Override
    public void deleteComment(int commentId) {
        commentMapper.deleteComment(commentId);
    }
}
