package org.csu.bookstore.persistence;

import org.apache.ibatis.annotations.Mapper;
import org.csu.bookstore.domain.Collection;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Mapper
@Component(value ="CollectionMapper")
public interface CollectionMapper {

    List<Collection> getCollectionByBookId(int bookId);

    List<Collection> getCollectionByUserId(int userId);

    @Transactional
    void insertCollection(Collection collection);

    @Transactional
    void deleteCollection(Collection collection);

    int getNextCollectionId();
}
