package org.csu.bookstore.persistence;

import org.apache.ibatis.annotations.Mapper;
import org.csu.bookstore.domain.CartItem;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Mapper
@Component(value ="CartMapper")
public interface CartMapper {

     List<CartItem> getCartByUserId(int userId);

     @Transactional
     void updateCartByBookId(CartItem cartItem);

     @Transactional
     void deleteBookFromCart(CartItem cartItem);

     @Transactional
     void addBookToCart(CartItem cart);

     @Transactional
     void deleteCartByCartId(int cartId);

     int getNextCartId();
}
