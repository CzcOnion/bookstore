package org.csu.bookstore.domain;

import java.io.Serializable;
import java.util.Date;

public class MessageReply implements Serializable {

    private int mreplyId;
    private int messageId;
    private int userId;
    private Date date;
    private String text;

    public int getMreplyId() {
        return mreplyId;
    }

    public void setMreplyId(int mreplyId) {
        this.mreplyId = mreplyId;
    }

    public int getMessageId() {
        return messageId;
    }

    public void setMessageId(int messageId) {
        this.messageId = messageId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
