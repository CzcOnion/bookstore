package org.csu.bookstore.persistence;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.csu.bookstore.domain.User;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Mapper
@Component(value ="UserMapper")
public interface UserMapper {

    User getUserByUserId(int userId);

    User getUserByUsernameAndPassword(User user);

    @Transactional
    void updateUser(User user);

    @Transactional
    void insertUser(User user);

    @Transactional
    void updatePassword(@Param("user") User user);

    int getNextUserId();
}
