package org.csu.bookstore.service.implement;

import org.csu.bookstore.domain.Message;
import org.csu.bookstore.domain.MessageReply;
import org.csu.bookstore.persistence.*;
import org.csu.bookstore.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;

public class MessageServiceImpl implements MessageService {

    @Autowired
    private MessageMapper messageMapper;

    @Override
    public void insertMessage(Message message) {
        message.setMessageId(messageMapper.getNextMessageId());
        messageMapper.insertMessage(message);
    }

    @Override
    public void insertMessageReply(MessageReply messageReply) {
        messageReply.setMreplyId(messageMapper.getNextMessageReplyId());
        messageMapper.insertMessageReply(messageReply);
    }

    @Override
    public void deleteMessage(int messageId) {
        messageMapper.deleteMessageReply(messageId);
        messageMapper.deleteMessage(messageId);
    }

    @Override
    public void deleteMessageReply(int messageRelyId) {
        messageMapper.deleteMessageReply(messageRelyId);
    }
}
