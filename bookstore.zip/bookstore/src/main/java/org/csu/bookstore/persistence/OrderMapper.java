package org.csu.bookstore.persistence;

import org.apache.ibatis.annotations.Mapper;
import org.csu.bookstore.domain.Order;
import org.csu.bookstore.domain.OrderDetail;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Mapper
@Component(value ="OrderMapper")
public interface OrderMapper {

    List<Order> getOrderByUserId(int userId);

    @Transactional
    void updateOrderByOrderId(Order order);

    @Transactional
    void addOrder(Order order);

    @Transactional
    void addOrderDetail(OrderDetail orderDetail);

    Order getOrderByOrderId(int orderId);

    int getNextOrderId();

    List<OrderDetail> getOrderDetailByOrderId(int orderId);

    int getNextOrderDetailId();
}
