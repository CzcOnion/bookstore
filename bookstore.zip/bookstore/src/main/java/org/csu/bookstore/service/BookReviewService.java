package org.csu.bookstore.service;

import org.csu.bookstore.domain.*;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface BookReviewService {

    @Transactional
    void insertBookReview(BookReview bookReview);

    @Transactional
    void updateBookReview(BookReview bookReview);

    @Transactional
    void deleteBookReview(int reviewId);

}
