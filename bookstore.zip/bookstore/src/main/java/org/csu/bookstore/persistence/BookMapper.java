package org.csu.bookstore.persistence;

import org.apache.ibatis.annotations.Mapper;
import org.csu.bookstore.domain.Book;
import org.csu.bookstore.domain.Image;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Mapper
@Component(value ="BookMapper")
public interface BookMapper {
    Book getBookByBookId(int bookId);

    List<Book> getBookListByItemId(int itemId);

    List<Book> getBookList();

    List<Book> SearchBookByBookId(String bookName);

    @Transactional
    void updateBook(Book book);

    @Transactional
    void insertBook(Book book);

    int getNextBookId();

    List<Image> getImageListByBookId(int bookId);
}
