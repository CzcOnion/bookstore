package org.csu.bookstore.service.implement;

import org.csu.bookstore.domain.CartItem;
import org.csu.bookstore.persistence.CartMapper;
import org.csu.bookstore.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class CartServiceImpl implements CartService {
    @Autowired
    private CartMapper cartMapper;


    @Override
    public void addCartItem(CartItem cartItem) {
        cartItem.setCartId(cartMapper.getNextCartId());
        cartMapper.addBookToCart(cartItem);
    }

    @Override
    public void deleteCartItem(CartItem cartItem) {
        cartMapper.deleteBookFromCart(cartItem);
    }

    @Override
    public List<CartItem> getCartItem(int userId) {
        return cartMapper.getCartByUserId(userId);
    }
}
