package org.csu.bookstore.service.implement;

import org.csu.bookstore.domain.*;
import org.csu.bookstore.persistence.*;
import org.csu.bookstore.service.BookReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookReviewServiceImpl implements BookReviewService {

    @Autowired
    private BookReviewMapper bookReviewMapper;

    @Autowired
    private MessageMapper messageMapper;


    @Override
    public void insertBookReview(BookReview bookReview) {
        bookReview.setReviewId(bookReviewMapper.getNextBookReviewId());
        bookReviewMapper.insertBookReview(bookReview);
    }

    @Override
    public void updateBookReview(BookReview bookReview) {
        bookReviewMapper.updateBookReview(bookReview);
    }

    @Override
    public void deleteBookReview(int reviewId) {
        BookReview bookReview = bookReviewMapper.getBookReviewByReviewId(reviewId);
        for(int i=0;i<bookReview.getMessagesList().size();i++) {
            Message message = bookReview.getMessagesList().get(i);
            messageMapper.deleteMessage(message.getMessageId());
            for (int k = 0; k<message.getMessageReplyList().size();k++)
            {
                messageMapper.deleteMessageReply(message.getMessageReplyList().get(k).getMreplyId());
            }
        }
        bookReviewMapper.deleteBookReview(reviewId);
    }


}
