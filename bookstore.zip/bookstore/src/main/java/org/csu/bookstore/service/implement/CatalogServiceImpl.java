package org.csu.bookstore.service.implement;

import org.csu.bookstore.domain.*;
import org.csu.bookstore.persistence.*;
import org.csu.bookstore.service.CatalogService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class CatalogServiceImpl implements CatalogService {

    @Autowired
    private BookMapper bookMapper;

    @Autowired
    private CommentMapper commentMapper;

    @Autowired
    private MessageMapper messageMapper;

    @Autowired
    private BookReviewMapper bookReviewMapper;

    @Autowired
    private AdmireMapper admireMapper;

    @Override
    public Book getBook(int bookId) {
        Book book = bookMapper.getBookByBookId(bookId);
        List<Image> imageList = bookMapper.getImageListByBookId(bookId);
        List<BookReview> bookReviewList = bookReviewMapper.getBookReviewByBookId(bookId);
        List<Comment> commentList = commentMapper.getCommentByBookId(bookId);
        book.setImageList(imageList);
        book.setBookReviewList(bookReviewList);
        book.setCommentList(commentList);
        return book;
    }

    @Override
    public List<Book> getBookList(int itemId) {
        List<Book> book = bookMapper.getBookListByItemId(itemId);
        for (int i = 0; i < book.size(); i++) {
            List<Image> imageList = bookMapper.getImageListByBookId(book.get(i).getBookId());
            List<BookReview> bookReviewList = bookReviewMapper.getBookReviewByBookId(book.get(i).getBookId());
            List<Comment> commentList = commentMapper.getCommentByBookId(book.get(i).getBookId());
            book.get(i).setImageList(imageList);
            book.get(i).setBookReviewList(bookReviewList);
            book.get(i).setCommentList(commentList);
        }
        return book;
    }

    @Override
    public List<Book> getBookList() {
        List<Book> book = bookMapper.getBookList();
        for (int i = 0; i < book.size(); i++) {
            List<Image> imageList = bookMapper.getImageListByBookId(book.get(i).getBookId());
            List<BookReview> bookReviewList = bookReviewMapper.getBookReviewByBookId(book.get(i).getBookId());
            book.get(i).setImageList(imageList);
            book.get(i).setBookReviewList(bookReviewList);
        }
        return book;
    }

    @Override
    public BookReview getReview(int reviewId) {
        BookReview bookReview = bookReviewMapper.getBookReviewByReviewId(reviewId);
        //评论
        List<Message> messageList = messageMapper.getMessageByReviewId(reviewId);
        for (int i = 0; i < messageList.size(); i++) {
            //评论回复
            List<MessageReply> messageReplyList = messageMapper.getMessageReplyByMessageId(messageList.get(i).getMessageId());
            messageList.get(i).setMessageReplyList(messageReplyList);
        }
        //点赞数
        int count = admireMapper.getAdmireByReviewId(reviewId).size();
        bookReview.setCount(count);
        bookReview.setMessagesList(messageList);
        return bookReview;
    }

    @Override
    public List<BookReview> getBookReviewList(int bookId){
        return bookReviewMapper.getBookReviewByBookId(bookId);
    }

    @Override
    public List<BookReview> getBookReviewList(){
        return bookReviewMapper.getBookReviewList();
    }

}