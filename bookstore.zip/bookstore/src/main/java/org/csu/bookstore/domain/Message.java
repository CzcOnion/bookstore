package org.csu.bookstore.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class Message implements Serializable {

    private int messageId;
    private int reviewId;
    private int userId;
    private Date date;
    private String text;
    private List<MessageReply> messageReplyList;

    public List<MessageReply> getMessageReplyList() {
        return messageReplyList;
    }

    public void setMessageReplyList(List<MessageReply> messageReplyList) {
        this.messageReplyList = messageReplyList;
    }

    public int getMessageId() {
        return messageId;
    }

    public void setMessageId(int messageId) {
        this.messageId = messageId;
    }

    public int getReviewId() {
        return reviewId;
    }

    public void setReviewId(int reviewId) {
        this.reviewId = reviewId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
