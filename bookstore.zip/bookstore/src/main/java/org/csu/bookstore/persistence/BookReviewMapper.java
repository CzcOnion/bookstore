package org.csu.bookstore.persistence;

import org.apache.ibatis.annotations.Mapper;
import org.csu.bookstore.domain.BookReview;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Mapper
@Component(value ="BookReviewMapper")
public interface BookReviewMapper {

    List<BookReview> getBookReviewByBookId(int bookId);

    BookReview getBookReviewByReviewId(int reviewId);

    @Transactional
    void insertBookReview(BookReview bookReview);

    @Transactional
    void updateBookReview(BookReview bookReview);

    @Transactional
    void deleteBookReview(int reviewId);

    int getNextBookReviewId();

    List<BookReview> getBookReviewList();
}
