package org.csu.bookstore.domain;

import java.io.Serializable;
import java.util.Date;

//序列化的意思你可以这么理解，对象可以作为字节流进行传输或保存
public class Admire implements Serializable {

    private int admireId;
    private int userId;
    private int reviewId;
    private Date date;

    public int getAdmireId() {
        return admireId;
    }

    public void setAdmireId(int admireId) {
        this.admireId = admireId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getReviewId() {
        return reviewId;
    }

    public void setReviewId(int reviewId) {
        this.reviewId = reviewId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
