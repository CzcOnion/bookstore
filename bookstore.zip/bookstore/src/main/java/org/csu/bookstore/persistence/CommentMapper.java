package org.csu.bookstore.persistence;

import org.apache.ibatis.annotations.Mapper;
import org.csu.bookstore.domain.Comment;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Mapper
@Component(value ="CommentMapper")
public interface CommentMapper {

    List<Comment> getCommentByBookId(int bookId);

    List<Comment> getCommentByUserId(int userId);

    Comment getCommentByCommentId(int commentId);

    @Transactional
    void insertComment(Comment comment);

    @Transactional
    void updateComment(Comment comment);

    @Transactional
    void deleteComment(int commentId);

    int getNextCommentId();
}
